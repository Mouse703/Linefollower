#include <Arduino.h>
#define Baudrate 115200
#define LED 12

void setup()
{
  pinMode(LED, OUTPUT);
}

void loop()
{ 
  digitalWrite(LED, HIGH);
  delay(1000);
  digitalWrite(LED, LOW);
}