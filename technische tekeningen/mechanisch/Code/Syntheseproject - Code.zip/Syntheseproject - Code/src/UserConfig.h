#include <Arduino.h>

const char* ssid = "DESKTOP-MAINPC";
const char* pswd = "blub0123456789";
const char* host = "ESP32-LVR";